package de.nexttvos.scanner;

import android.app.Activity;
import android.app.ActivityManager;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.Color;
import android.graphics.Typeface;
import android.opengl.GLES20;
import android.opengl.GLSurfaceView;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.StatFs;
import android.util.DisplayMetrics;
import android.view.Display;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import java.io.BufferedReader;
import java.io.FileReader;
import java.util.Arrays;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

import javax.microedition.khronos.egl.EGLConfig;
import javax.microedition.khronos.opengles.GL10;

/** Geraete-Scanner: zeigt nur Werte, die direkt vom Geraet ausgelesen wurden. */
public class MainActivity extends Activity {
    private TextView text;
    private volatile String gpu = "wird ermittelt ...";

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(Color.rgb(16, 20, 28));

        GLSurfaceView gl = new GLSurfaceView(this);
        gl.setEGLContextClientVersion(2);
        gl.setRenderer(new GLSurfaceView.Renderer() {
            public void onSurfaceCreated(GL10 g, EGLConfig c) {
                gpu = GLES20.glGetString(GLES20.GL_VENDOR) + " / "
                    + GLES20.glGetString(GLES20.GL_RENDERER) + " / "
                    + GLES20.glGetString(GLES20.GL_VERSION);
                runOnUiThread(new Runnable() { public void run() { text.setText(report()); } });
            }
            public void onSurfaceChanged(GL10 g, int w, int h) { }
            public void onDrawFrame(GL10 g) { }
        });
        root.addView(gl, new FrameLayout.LayoutParams(1, 1));

        ScrollView sv = new ScrollView(this);
        sv.setFocusable(true);
        sv.setPadding(48, 32, 48, 32);
        text = new TextView(this);
        text.setTextColor(Color.WHITE);
        text.setTypeface(Typeface.MONOSPACE);
        text.setTextSize(15);
        text.setText(report());
        sv.addView(text);
        root.addView(sv, new FrameLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        setContentView(root);
        sv.requestFocus();
    }

    private String report() {
        StringBuilder s = new StringBuilder();
        s.append("NEXT TV OS - GERAETE-SCANNER (mit Pfeil runter/hoch scrollen)\n");
        s.append("Alles unten wurde direkt vom Geraet ausgelesen.\n\n");

        s.append("== GERAET ==\n");
        s.append("Hersteller: ").append(Build.MANUFACTURER).append('\n');
        s.append("Marke: ").append(Build.BRAND).append('\n');
        s.append("Modell: ").append(Build.MODEL).append('\n');
        s.append("Device/Product: ").append(Build.DEVICE).append(" / ").append(Build.PRODUCT).append('\n');
        s.append("Board/Hardware: ").append(Build.BOARD).append(" / ").append(Build.HARDWARE).append('\n');

        s.append("\n== SOFTWARE ==\n");
        s.append("Android: ").append(Build.VERSION.RELEASE).append(" (API ").append(Build.VERSION.SDK_INT).append(")\n");
        s.append("Sicherheitspatch: ").append(Build.VERSION.SECURITY_PATCH).append('\n');
        s.append("Build: ").append(Build.DISPLAY).append('\n');
        s.append("ABIs: ").append(Arrays.toString(Build.SUPPORTED_ABIS)).append('\n');
        s.append("Leanback (TV-Modus): ").append(getPackageManager().hasSystemFeature(PackageManager.FEATURE_LEANBACK)).append('\n');

        s.append("\n== CPU ==\n");
        s.append("Kerne (aktiv): ").append(Runtime.getRuntime().availableProcessors()).append('\n');
        Set<String> cpu = new LinkedHashSet<String>();
        for (String l : lines("/proc/cpuinfo")) {
            String k = l.toLowerCase();
            if (k.startsWith("processor") && l.contains(":") && !l.matches("processor\\s*:\\s*\\d+")
                || k.startsWith("hardware") || k.startsWith("model name")
                || k.startsWith("cpu architecture") || k.startsWith("cpu implementer")
                || k.startsWith("cpu part")) cpu.add(l);
        }
        for (String l : cpu) s.append(l).append('\n');
        for (int i = 0; i < Runtime.getRuntime().availableProcessors(); i++) {
            List<String> f = lines("/sys/devices/system/cpu/cpu" + i + "/cpufreq/cpuinfo_max_freq");
            s.append("cpu").append(i).append(" max kHz: ").append(f.isEmpty() ? "nicht lesbar" : f.get(0)).append('\n');
        }

        s.append("\n== ARBEITSSPEICHER ==\n");
        for (String l : lines("/proc/meminfo")) {
            if (l.startsWith("MemTotal") || l.startsWith("MemFree") || l.startsWith("MemAvailable")) s.append(l).append('\n');
        }
        ActivityManager am = (ActivityManager) getSystemService(Context.ACTIVITY_SERVICE);
        ActivityManager.MemoryInfo mi = new ActivityManager.MemoryInfo();
        am.getMemoryInfo(mi);
        s.append("totalMem MB: ").append(mi.totalMem / 1048576).append('\n');
        s.append("availMem MB: ").append(mi.availMem / 1048576).append('\n');
        s.append("App-Heap-Limit MB: ").append(am.getMemoryClass()).append(" (gross: ").append(am.getLargeMemoryClass()).append(")\n");
        s.append("Low-RAM-Geraet: ").append(am.isLowRamDevice()).append('\n');

        s.append("\n== SPEICHERPLATZ (Daten) ==\n");
        StatFs st = new StatFs(Environment.getDataDirectory().getPath());
        s.append("Gesamt MB: ").append(st.getTotalBytes() / 1048576).append('\n');
        s.append("Frei MB: ").append(st.getAvailableBytes() / 1048576).append('\n');

        s.append("\n== GRAFIK ==\n");
        s.append("GPU: ").append(gpu).append('\n');
        Display d = getWindowManager().getDefaultDisplay();
        DisplayMetrics dm = new DisplayMetrics();
        d.getRealMetrics(dm);
        s.append("Aufloesung: ").append(dm.widthPixels).append("x").append(dm.heightPixels)
         .append(" Dichte ").append(dm.densityDpi).append(" dpi\n");
        s.append("Bildwiederholrate: ").append(d.getRefreshRate()).append(" Hz\n");
        for (Display.Mode m : d.getSupportedModes()) {
            s.append("Modus: ").append(m.getPhysicalWidth()).append("x").append(m.getPhysicalHeight())
             .append(" @ ").append(m.getRefreshRate()).append(" Hz\n");
        }

        s.append("\n== STARTBILDSCHIRM (LAUNCHER) ==\n");
        PackageManager pm = getPackageManager();
        Intent home = new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME);
        ResolveInfo def = pm.resolveActivity(home, PackageManager.MATCH_DEFAULT_ONLY);
        s.append("Standard-Home: ").append(def == null ? "keiner" : def.activityInfo.packageName + " / " + def.activityInfo.name).append('\n');
        for (ResolveInfo r : pm.queryIntentActivities(home, 0)) {
            s.append("Home-faehig: ").append(r.activityInfo.packageName).append('\n');
        }

        s.append("\n== INSTALLIERTE TV-APPS ==\n");
        Intent lb = new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LEANBACK_LAUNCHER);
        for (ResolveInfo r : pm.queryIntentActivities(lb, 0)) {
            s.append(r.loadLabel(pm)).append("  [").append(r.activityInfo.packageName).append("]\n");
        }
        return s.toString();
    }

    private static List<String> lines(String path) {
        java.util.ArrayList<String> out = new java.util.ArrayList<String>();
        try {
            BufferedReader r = new BufferedReader(new FileReader(path));
            String l;
            while ((l = r.readLine()) != null && out.size() < 400) out.add(l.trim());
            r.close();
        } catch (Exception e) { /* nicht lesbar */ }
        return out;
    }
}
