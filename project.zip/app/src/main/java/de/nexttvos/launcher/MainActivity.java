package de.nexttvos.launcher;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.PorterDuff;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.os.Handler;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;

/** Next TV OS: nur Favoriten, grosser Titel, Farbverlauf aus der markierten App. Sparsam fuer Mali-470. */
public class MainActivity extends Activity {
    private static final int BG = 0xFF0B0D12;
    private static final String[] DEFAULTS = {
        "com.netflix.ninja", "com.google.android.youtube.tv", "com.amazon.amazonvideo.livingroom",
        "com.disney.disneyplus", "com.google.android.youtube.tvmusic"
    };

    private static class App {
        String pkg, label;
        Drawable icon;
        Runnable run;
    }

    private SharedPreferences sp;
    private PackageManager pm;
    private float dens;
    private TextView greeting, clock, title;
    private LinearLayout dock;
    private String focusPkg;
    private final Handler handler = new Handler();
    private final Runnable tick = new Runnable() {
        public void run() {
            clock.setText(new SimpleDateFormat("HH:mm", Locale.GERMANY).format(new Date()));
            int h = Calendar.getInstance().get(Calendar.HOUR_OF_DAY);
            greeting.setText(h >= 5 && h < 11 ? "Guten Morgen" : h >= 11 && h < 17 ? "Guten Tag"
                : h >= 17 && h < 22 ? "Guten Abend" : "Gute Nacht");
            handler.postDelayed(this, 30000);
        }
    };

    private int dp(float v) { return (int) (v * dens + 0.5f); }

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        sp = getSharedPreferences("nexttvos", MODE_PRIVATE);
        pm = getPackageManager();
        dens = getResources().getDisplayMetrics().density;

        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(BG);
        ImageView bgImg = new ImageView(this);
        bgImg.setScaleType(ImageView.ScaleType.CENTER_CROP);
        bgImg.setImageResource(R.drawable.bg);
        root.addView(bgImg, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        LinearLayout tl = new LinearLayout(this);
        tl.setOrientation(LinearLayout.VERTICAL);
        greeting = new TextView(this);
        greeting.setTextColor(0xCCFFFFFF);
        greeting.setTextSize(15);
        clock = new TextView(this);
        clock.setTextColor(Color.WHITE);
        clock.setTextSize(34);
        clock.setTypeface(Typeface.create("sans-serif-medium", Typeface.NORMAL));
        tl.addView(greeting);
        tl.addView(clock);
        FrameLayout.LayoutParams tlp = new FrameLayout.LayoutParams(
            ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.TOP | Gravity.START);
        tlp.setMargins(dp(48), dp(30), 0, 0);
        root.addView(tl, tlp);

        View gear = makeRound();
        FrameLayout.LayoutParams gp = new FrameLayout.LayoutParams(dp(42), dp(42), Gravity.TOP | Gravity.END);
        gp.setMargins(0, dp(34), dp(48), 0);
        root.addView(gear, gp);

        LinearLayout tx = new LinearLayout(this);
        tx.setOrientation(LinearLayout.VERTICAL);
        title = new TextView(this);
        title.setTextColor(Color.WHITE);
        title.setTextSize(46);
        title.setTypeface(Typeface.create("sans-serif-medium", Typeface.BOLD));
        title.setSingleLine(true);
        tx.addView(title);
        FrameLayout.LayoutParams txp = new FrameLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.BOTTOM | Gravity.START);
        txp.setMargins(dp(48), 0, dp(48), dp(138));
        root.addView(tx, txp);

        HorizontalScrollView hsv = new HorizontalScrollView(this);
        hsv.setHorizontalScrollBarEnabled(false);
        hsv.setFillViewport(true);
        hsv.setClipChildren(false);
        hsv.setClipToPadding(false);
        hsv.setPadding(dp(40), dp(14), dp(40), dp(14));
        LinearLayout outer = new LinearLayout(this);
        outer.setGravity(Gravity.CENTER);
        outer.setClipChildren(false);
        dock = new LinearLayout(this);
        dock.setGravity(Gravity.CENTER_VERTICAL);
        dock.setClipChildren(false);
        dock.setPadding(dp(8), dp(8), dp(8), dp(8));
        GradientDrawable pill = new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, new int[]{0x30FFFFFF, 0x4D000000});
        pill.setCornerRadius(dp(40));
        pill.setStroke(Math.max(1, dp(1)), 0x66FFFFFF);
        dock.setBackground(pill);
        outer.addView(dock, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        hsv.addView(outer, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        FrameLayout.LayoutParams hp = new FrameLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.BOTTOM);
        hp.bottomMargin = dp(30);
        root.addView(hsv, hp);
        setContentView(root);
    }

    @Override
    protected void onResume() {
        super.onResume();
        handler.post(tick);
        buildDock();
    }

    @Override
    protected void onPause() {
        super.onPause();
        handler.removeCallbacks(tick);
    }

    // ---------- Daten ----------

    private List<App> loadApps() {
        Intent li = new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LEANBACK_LAUNCHER);
        List<App> out = new ArrayList<App>();
        Set<String> seen = new HashSet<String>();
        for (ResolveInfo ri : pm.queryIntentActivities(li, 0)) {
            String pkg = ri.activityInfo.packageName;
            if (pkg.equals(getPackageName()) || !seen.add(pkg)) continue;
            App a = new App();
            a.pkg = pkg;
            a.label = String.valueOf(ri.loadLabel(pm));
            a.icon = ri.loadIcon(pm);
            out.add(a);
        }
        Collections.sort(out, new Comparator<App>() {
            public int compare(App x, App y) { return x.label.compareToIgnoreCase(y.label); }
        });
        return out;
    }

    private List<String> getFavs() {
        List<String> l = new ArrayList<String>();
        String s = sp.getString("f", "");
        if (s.length() > 0) for (String p : s.split(",")) if (p.length() > 0) l.add(p);
        return l;
    }

    private void putFavs(List<String> l) {
        StringBuilder sb = new StringBuilder();
        for (String p : l) { if (sb.length() > 0) sb.append(','); sb.append(p); }
        sp.edit().putString("f", sb.toString()).apply();
    }

    private void launch(String pkg) {
        Intent i = pm.getLeanbackLaunchIntentForPackage(pkg);
        if (i == null) i = pm.getLaunchIntentForPackage(pkg);
        if (i == null) { Toast.makeText(this, "App lässt sich nicht starten", Toast.LENGTH_SHORT).show(); return; }
        startActivity(i);
    }

    private void editFavorites() {
        final List<App> all = loadApps();
        final List<String> work = getFavs();
        String[] names = new String[all.size()];
        boolean[] checked = new boolean[all.size()];
        for (int i = 0; i < all.size(); i++) {
            names[i] = all.get(i).label;
            checked[i] = work.contains(all.get(i).pkg);
        }
        new AlertDialog.Builder(this, android.R.style.Theme_Material_Dialog)
            .setTitle("Favoriten wählen")
            .setMultiChoiceItems(names, checked, new DialogInterface.OnMultiChoiceClickListener() {
                public void onClick(DialogInterface d, int which, boolean on) {
                    String p = all.get(which).pkg;
                    if (on) { if (!work.contains(p)) work.add(p); } else work.remove(p);
                }
            })
            .setPositiveButton("Fertig", null)
            .setOnDismissListener(new DialogInterface.OnDismissListener() {
                public void onDismiss(DialogInterface d) { putFavs(work); focusPkg = null; buildDock(); }
            })
            .show();
    }

    // ---------- Oberflaeche ----------

    private void buildDock() {
        dock.removeAllViews();
        List<App> all = loadApps();
        if (!sp.contains("f")) {
            List<String> d = new ArrayList<String>();
            for (String p : DEFAULTS) for (App a : all) if (a.pkg.equals(p)) { d.add(p); break; }
            putFavs(d);
        }
        for (String p : getFavs()) for (App a : all) if (a.pkg.equals(p)) { dock.addView(makeTile(a)); break; }
        App plus = new App();
        plus.pkg = "system.plus";
        plus.label = "Favoriten bearbeiten";
        plus.run = new Runnable() { public void run() { editFavorites(); } };
        dock.addView(makeTile(plus));

        View target = focusPkg == null ? null : findTag(dock, focusPkg);
        if (target != null) target.requestFocus(); else dock.requestFocus();
    }

    private View findTag(ViewGroup g, String tag) {
        for (int i = 0; i < g.getChildCount(); i++) {
            View c = g.getChildAt(i);
            if (tag.equals(c.getTag())) return c;
        }
        return null;
    }

    private View makeRound() {
        FrameLayout f = new FrameLayout(this);
        final GradientDrawable bg = new GradientDrawable();
        bg.setShape(GradientDrawable.OVAL);
        bg.setColor(0x33FFFFFF);
        f.setBackground(bg);
        ImageView iv = new ImageView(this);
        iv.setImageResource(android.R.drawable.ic_menu_preferences);
        iv.setColorFilter(Color.WHITE, PorterDuff.Mode.SRC_IN);
        FrameLayout.LayoutParams ip = new FrameLayout.LayoutParams(dp(22), dp(22), Gravity.CENTER);
        f.addView(iv, ip);
        f.setFocusable(true);
        f.setClickable(true);
        f.setOutlineProvider(null);
        f.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            public void onFocusChange(View v, boolean on) {
                float s = on ? 1.15f : 1f;
                v.animate().scaleX(s).scaleY(s).setDuration(120).start();
                bg.setColor(on ? 0xFFF2F2F2 : 0x33FFFFFF);
                if (on) title.setText("Einstellungen");
            }
        });
        f.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                try { startActivity(new Intent(Settings.ACTION_SETTINGS)); }
                catch (Exception e) { Toast.makeText(MainActivity.this, "Nicht verfügbar", Toast.LENGTH_SHORT).show(); }
            }
        });
        return f;
    }

    private View makeTile(final App a) {
        final FrameLayout t = new FrameLayout(this);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(dp(60), dp(60));
        lp.setMargins(dp(4), 0, dp(4), 0);
        t.setLayoutParams(lp);
        final GradientDrawable bg = new GradientDrawable();
        bg.setCornerRadius(dp(14));
        bg.setColor(0x1AFFFFFF);
        t.setBackground(bg);
        t.setOutlineProvider(null);
        t.setTag(a.pkg);

        if (a.icon != null) {
            ImageView iv = new ImageView(this);
            iv.setImageDrawable(a.icon);
            t.addView(iv, new FrameLayout.LayoutParams(dp(40), dp(40), Gravity.CENTER));
        } else {
            TextView tv = new TextView(this);
            tv.setText("+");
            tv.setTextColor(Color.WHITE);
            tv.setTextSize(26);
            tv.setGravity(Gravity.CENTER);
            t.addView(tv, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        }

        t.setFocusable(true);
        t.setClickable(true);
        t.setLongClickable(a.run == null);
        t.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            public void onFocusChange(View v, boolean on) {
                float s = on ? 1.14f : 1f;
                v.animate().scaleX(s).scaleY(s).setDuration(120).start();
                v.setTranslationZ(on ? dp(10) : 0);
                bg.setColor(on ? 0xEBF2F2F2 : 0x1AFFFFFF);
                if (on) {
                    focusPkg = a.pkg;
                    title.setText(a.label);
                }
            }
        });
        t.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) { if (a.run != null) a.run.run(); else launch(a.pkg); }
        });
        t.setOnLongClickListener(new View.OnLongClickListener() {
            public boolean onLongClick(View v) {
                if (a.run != null) return true;
                List<String> f = getFavs();
                f.remove(a.pkg);
                putFavs(f);
                focusPkg = null;
                Toast.makeText(MainActivity.this, "Aus Favoriten entfernt", Toast.LENGTH_SHORT).show();
                buildDock();
                return true;
            }
        });
        return t;
    }
}
